Title:  Resource Tracker for Astroneer 1.3
Descrition: *Astroneer* is a space exploration and sandbox adventure game developed by System Era Softworks. Players explore colorful planets, gather resources, craft tools, and build bases while uncovering mysteries across the solar system. The game emphasizes creativity, cooperation, and discovery in an open-world environment.
Author: SkyLightFox
Updated: 7/22/2025 16:33 EST

# Information {From Astroneer Developers/Web Site}

**Release Date:** December 16, 2016 (Early Access), February 6, 2019 (Full Release)  
**Developer:** System Era Softworks  
**Platforms:** Windows, Xbox One, PlayStation 4, Nintendo Switch  
**Game Modes:** Single-player, Online Co-op (up to 4 players)

## Gameplay Overview

- Explore procedurally generated planets with unique biomes and hazards.
- Gather and refine resources to craft tools, vehicles, and base modules.
- Research new technologies to unlock advanced equipment.
- Survive environmental challenges such as storms, low oxygen, and terrain obstacles.
- Collaborate with friends in multiplayer to build, explore, and automate together.

## Notable Features

- **Terrain Tool:** Shape and manipulate the landscape for mining, building, and exploration.
- **Automation:** Use auto arms, sensors, and platforms to automate resource collection and processing.
- **Base Building:** Modular base components allow for creative layouts and efficient workflows.
- **Space Travel:** Build and launch shuttles to visit other planets and moons in the solar system.
- **Customization:** Personalize your Astroneer with suits, palettes, and emotes.

For more details, visit the [Official Astroneer Website](https://astroneer.space/).

# Common Resources
- Compound
- Resin
- Organic
- Clay
- Quartz
- Graphite
- Ammonium

# Refined Resources
- Aluminum (from Laterite)
- Copper (from Malachite)
- Tungsten (from Wolframite)
- Iron (from Hematite)
- Steel (Alloy)
- Titanium (from Titanite)
- Ceramic (from Clay)
- Glass (from Quartz)
- Plastic (Alloy)
- Rubber (Alloy)

# Gases
- Hydrogen
- Nitrogen
- Argon
- Methane
- Sulfur
- Helium

# Rare Resources
- Astronium

# Tracker Table

| Resource   | Amount Owned | Needed For                | Notes                |
|------------|-------------|---------------------------|----------------------|
| Compound   |             | Tethers, Platforms        |                      |
| Resin      |             | Platforms, Storage        |                      |
| Aluminum   |             | Medium Printer, Vehicles  | Smelt Laterite       |
| Copper     |             | Small Generator, Solar    | Smelt Malachite      |
| Tungsten   |             | Chemistry Lab, Drill      | Smelt Wolframite     |
| Iron       |             | Large Shredder, RTG       | Smelt Hematite       |
| ...        |             | ...                       | ...                  |

# Instructions:
# - Fill in "Amount Owned" as you collect resources.
# - Add new rows for additional resources as needed.
# - Use "Needed For" and "Notes" to track crafting requirements.\

# Useful Links

- [Official Astroneer Wiki](https://astroneer.wiki.gg/)
- [Astroneer Resource Guide](https://astroneer.fandom.com/wiki/Resources)
- [Astroneer Crafting Guide](https://astroneer.fandom.com/wiki/Crafting)
- [Resource Tracking Spreadsheet (Community)](https://docs.google.com/spreadsheets/d/1wQwKk6pQwWQwKk6pQwWQwKk6pQwWQwKk6pQwWQwKk6pQ/edit)

# Tips

- Use storage platforms to organize resources by type.
- Smelt raw resources early to save space.
- Track rare resources and gases for late-game crafting.
- Check the wiki for planet-specific resource locations.
- Automate resource collection with auto arms and storage.

# Vehicles

Astroneer features a variety of vehicles to aid in exploration and resource gathering:

| Vehicle         | Seats | Power Source      | Storage Options         | Notes                          |
|-----------------|-------|-------------------|------------------------|---------------------------------|
| Small Rover     | 1     | Small Generator   | Small Storage          | Good for early exploration      |
| Medium Rover    | 2     | Medium Battery    | Medium Storage, Trailer| Versatile, can tow trailers     |
| Large Rover     | 4     | RTG, Solar, Battery| Large Storage, Trailer | High capacity, best for hauling |
| Tractor         | 1     | Small Generator   | Small Storage, Trailer | Compact, can tow trailers       |
| Buggy           | 1     | Small Generator   | Small Storage          | Fast, but limited storage       |
| Shuttles        | 1-3   | Hydrazine         | Storage Modules        | For interplanetary travel       |

**Tip:** Attach storage and power modules to vehicles for extended trips.
# Utilities

Astroneer provides several utility items and modules to assist with resource management, crafting, and exploration:

| Utility            | Function                                 | Notes                              |
|--------------------|------------------------------------------|------------------------------------|
| Smelting Furnace   | Refines raw resources into refined forms | Essential for metal production     |
| Soil Centrifuge    | Extracts resources from soil             | Useful for basic resources         |
| Chemistry Lab      | Crafts composite/alloy resources         | Needed for advanced materials      |
| Atmospheric Condenser | Collects atmospheric gases           | Required for gas-based crafting    |
| Trade Platform     | Trades scrap for resources               | Great for acquiring rare items     |
| Shredder           | Recycles unwanted items into scrap       | Use with Trade Platform            |
| Auto Arm           | Automates resource transfer              | Useful for automation setups       |
| Medium/RTG         | Provides continuous power                | RTG is best for late-game bases    |
| Packager           | Packs items for transport                | Handy for moving large objects     |

**Tip:** Combine automation utilities for efficient resource processing and storage.

# Add-Ons & Mods

While *Astroneer* does not officially support mods, the community has created a few tools and add-ons to enhance gameplay:

| Add-On/Tool         | Description                                 | Notes                                      |
|---------------------|---------------------------------------------|--------------------------------------------|
| Save Game Editors   | Edit inventory, resources, and unlocks      |                                            |
| Resource Trackers   | External spreadsheets or apps for tracking  |                                            |
| Blueprint Planners  | Plan base layouts and automation setups     |                                            |
| Visual Mods         | Texture packs and visual tweaks (PC only)   |                                            |

